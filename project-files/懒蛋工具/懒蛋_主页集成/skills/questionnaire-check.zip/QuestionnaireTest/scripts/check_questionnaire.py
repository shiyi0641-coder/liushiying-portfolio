#!/usr/bin/env python3
"""
问卷录入检查脚本

功能：
1. 读取问卷网在线文档（通过docs-skills-assistant API）
2. 读取导出的录入文件（xlsx格式）
3. 对比检查题目、选项、逻辑代码的一致性
4. 输出错误报告（不自动修正）

用法：
    python3 check_questionnaire.py <问卷文档链接> <录入文件.xlsx>

输出：
    JSON格式的检查报告，包含发现的所有问题
"""

import sys
import os
import json
import re
import subprocess
import pandas as pd
from typing import Dict, List, Any, Tuple


def call_docs_api(url: str) -> str:
    """调用docs-skills-assistant API获取问卷内容"""
    script_path = os.path.expanduser("~/.openclaw/skills/docs-skills-assistant/scripts/call_skills_api.py")
    result = subprocess.run(
        ["python3", script_path, "summarize", "--url", url],
        capture_output=True,
        text=True
    )
    if result.returncode != 0:
        print(f"ERROR: 无法读取问卷文档 - {result.stderr}", file=sys.stderr)
        sys.exit(1)
    return result.stdout


def parse_doc_content(content: str) -> Dict[str, Any]:
    """解析问卷文档内容，提取题目结构"""
    questions = {}
    
    # 先找到所有HTML表格
    tables = re.findall(r'<table>.*?</table>', content, re.DOTALL | re.IGNORECASE)
    
    for table in tables:
        # 提取表格中的所有行
        rows = re.findall(r'<tr>(.*?)</tr>', table, re.DOTALL | re.IGNORECASE)
        
        for row in rows:
            # 提取行中的所有单元格
            cells = re.findall(r'<td>(.*?)</td>', row, re.DOTALL | re.IGNORECASE)
            if len(cells) >= 2:
                # 第一个单元格通常是题号或题目
                first_cell = cells[0].strip()
                second_cell = cells[1].strip()
                
                # 检查第一列是否是题号（如 "S1.【使用场景】..."）
                q_match = re.match(r'^([A-Z]\d+)\.', first_cell) or re.match(r'^([A-Z]\d+)\【', first_cell)
                if q_match:
                    q_id = q_match.group(1)
                    title = first_cell
                    
                    # 判断题型
                    q_type = None
                    if '（单选）' in title or '(单选)' in title:
                        q_type = '单选'
                    elif '（多选）' in title or '(多选)' in title:
                        q_type = '多选'
                    elif '填空' in title:
                        q_type = '填空'
                    
                    # 提取逻辑说明（如 "当S2=1或S3=1出示"）
                    logic_desc = None
                    logic_match = re.search(r'[（\(](当[^）\)]+)[）\)]', title)
                    if logic_match:
                        logic_desc = logic_match.group(1)
                    
                    questions[q_id] = {
                        'id': q_id,
                        'title': title,
                        'type': q_type,
                        'options': [],
                        'logic': logic_desc
                    }
                    
                    # 解析第二列的选项（按换行分割）
                    option_lines = second_cell.split('\n')
                    opt_num = 1
                    for opt_line in option_lines:
                        opt_line = opt_line.strip()
                        if opt_line and not opt_line.startswith('--'):
                            # 移除前缀如【消费】【直播】等
                            opt_text = re.sub(r'^【[^】]+】', '', opt_line).strip()
                            if opt_text:
                                questions[q_id]['options'].append({
                                    'num': str(opt_num),
                                    'text': opt_text
                                })
                                opt_num += 1
    
    return questions


def parse_excel(file_path: str) -> Dict[str, Any]:
    """解析录入的Excel文件"""
    df = pd.read_excel(file_path, sheet_name='data', header=None)
    
    questions = {}
    current_q = None
    
    for idx, row in df.iterrows():
        q_id = str(row[0]) if pd.notna(row[0]) else None
        
        # 判断是否是题目行（题号列不为空，且是字母+数字格式）
        if q_id and re.match(r'^[A-Z]\d+$', q_id):
            current_q = q_id
            questions[q_id] = {
                'id': q_id,
                'title': str(row[1]) if pd.notna(row[1]) else '',
                'type': str(row[2]) if pd.notna(row[2]) else None,
                'logic': str(row[3]) if pd.notna(row[3]) else None,
                'options': [],
                'row': idx
            }
        # 判断是否是选项行（题号列为数字，且当前有题目上下文）
        elif current_q and q_id and re.match(r'^\d+$', q_id):
            opt_text = str(row[1]) if pd.notna(row[1]) else ''
            opt_tag = str(row[2]) if pd.notna(row[2]) else None
            questions[current_q]['options'].append({
                'num': q_id,
                'text': opt_text,
                'tag': opt_tag,
                'row': idx
            })
    
    return questions


def is_reference_option(text: str) -> bool:
    """检查是否是引用选项（如「引用C1所选选项」、「引用B11选项」等）"""
    # 匹配各种引用格式：引用XX选项、引用XX所选选项
    return bool(re.search(r'引用[A-Z]\d+', text))


def clean_title(title: str) -> str:
    """清理题目文字，去除题号前缀、HTML标签、题型标注等"""
    # 移除HTML标签
    title = re.sub(r'<[^>]+>', '', title)
    # 移除题号前缀（如 "S2.【降频感知】"、"A1.【大类归因】"）
    title = re.sub(r'^[A-Z]\d+\.[【\[][^】\]]+[】\]]', '', title)
    # 移除题型标注（单选/多选）
    title = re.sub(r'[（\(]单选[）\)]', '', title)
    title = re.sub(r'[（\(]多选[）\)]', '', title)
    # 移除换行和多余空格
    title = title.replace('\n', '').replace(' ', '')
    return title.strip()


def check_logic_syntax(logic_code: str) -> List[str]:
    """检查逻辑代码语法是否正确，返回错误列表"""
    errors = []
    if not logic_code or logic_code == 'nan' or pd.isna(logic_code):
        return errors
    
    logic_code = str(logic_code).strip()
    
    # 基本语法检查
    # 1. 检查是否包含 Q. （逻辑代码必须引用题目）
    if 'Q.' not in logic_code:
        errors.append("逻辑代码应包含 'Q.' 引用")
    
    # 2. 检查括号匹配
    open_parens = logic_code.count('(')
    close_parens = logic_code.count(')')
    if open_parens != close_parens:
        errors.append(f"括号不匹配：左括号{open_parens}个，右括号{close_parens}个")
    
    # 3. 检查常见函数调用
    valid_functions = ['select', 'input', 'isin', 'include', 'notinclude', 'any', 'notin', 'asInt', 'asFloat', 'row', 'score']
    # 提取所有函数调用
    func_calls = re.findall(r'\.(\w+)\(', logic_code)
    for func in func_calls:
        if func not in valid_functions:
            errors.append(f"未知函数: '{func}'")
    
    # 4. 检查题号格式（Q.Q1 中的 Q1 应该是字母+数字）
    q_refs = re.findall(r'Q\.([A-Z]\d+)\.', logic_code)
    for q_ref in q_refs:
        if not re.match(r'^[A-Z]\d+$', q_ref):
            errors.append(f"题号格式错误: '{q_ref}'")
    
    # 5. 检查逻辑运算符
    if '&&' in logic_code or '||' in logic_code:
        # 检查是否有括号包裹复合条件
        if logic_code.count('(') < 2:
            errors.append("使用 && 或 || 时建议用括号包裹条件，避免逻辑混乱")
    
    return errors


def check_questions(doc_qs: Dict, excel_qs: Dict) -> List[Dict]:
    """对比检查题目一致性"""
    issues = []
    
    # 检查题目缺失
    doc_ids = set(doc_qs.keys())
    excel_ids = set(excel_qs.keys())
    
    missing_in_excel = doc_ids - excel_ids
    for q_id in sorted(missing_in_excel):
        issues.append({
            'level': 'ERROR',
            'type': '题目缺失',
            'question': q_id,
            'message': f'文档中的 {q_id} 题在录入文件中缺失'
        })
    
    missing_in_doc = excel_ids - doc_ids
    for q_id in sorted(missing_in_doc):
        issues.append({
            'level': 'WARNING',
            'type': '多余题目',
            'question': q_id,
            'message': f'录入文件中的 {q_id} 题在文档中未找到'
        })
    
    # 检查共同题目的选项
    common_ids = doc_ids & excel_ids
    for q_id in sorted(common_ids):
        doc_q = doc_qs[q_id]
        excel_q = excel_qs[q_id]
        
        # 检查题型
        if doc_q.get('type') and excel_q.get('type'):
            if doc_q['type'] != excel_q['type']:
                issues.append({
                    'level': 'ERROR',
                    'type': '题型不一致',
                    'question': q_id,
                    'message': f'文档为"{doc_q["type"]}", 录入为"{excel_q["type"]}"'
                })
        
        # 检查题目文字（题干）- 去除题号前缀和HTML标签后比较
        if doc_q.get('title') and excel_q.get('title'):
            doc_title_clean = clean_title(doc_q['title'])
            excel_title_clean = clean_title(excel_q['title'])
            
            if doc_title_clean != excel_title_clean:
                issues.append({
                    'level': 'WARNING',
                    'type': '题目文字不一致',
                    'question': q_id,
                    'message': f'题干文字与文档不一致',
                    'doc': doc_title_clean[:80],
                    'excel': excel_title_clean[:80]
                })
        
        # 检查逻辑代码
        doc_logic = doc_q.get('logic')
        excel_logic = excel_q.get('logic')
        
        # 检查逻辑代码语法
        if excel_logic and str(excel_logic) != 'nan':
            logic_errors = check_logic_syntax(excel_logic)
            if logic_errors:
                for error in logic_errors:
                    issues.append({
                        'level': 'WARNING',
                        'type': '逻辑代码语法问题',
                        'question': q_id,
                        'message': error,
                        'logic': str(excel_logic)[:100]
                    })
        
        # 对比文档逻辑说明和Excel逻辑代码
        # 文档中有逻辑说明但Excel中没有逻辑代码
        if doc_logic and (not excel_logic or str(excel_logic) == 'nan'):
            issues.append({
                'level': 'WARNING',
                'type': '逻辑代码缺失',
                'question': q_id,
                'message': f'文档中有逻辑说明"{doc_logic}"，但Excel中未设置逻辑代码',
                'doc_logic': doc_logic
            })
        
        # 检查选项数量（排除引用选项）
        doc_opts_raw = doc_q.get('options', [])
        excel_opts_raw = excel_q.get('options', [])
        
        # 分离引用选项和普通选项
        doc_ref_opts = [opt for opt in doc_opts_raw if is_reference_option(opt['text'])]
        doc_normal_opts = [opt for opt in doc_opts_raw if not is_reference_option(opt['text'])]
        
        # 判断该题目是否包含引用选项
        has_reference_option = len(doc_ref_opts) > 0
        
        # 如果有引用选项，添加提示而非错误，并跳过选项数量和文本检查
        if has_reference_option:
            for ref_opt in doc_ref_opts:
                issues.append({
                    'level': 'INFO',
                    'type': '引用选项',
                    'question': q_id,
                    'option': ref_opt['num'],
                    'message': f'选项{ref_opt["num"]}是引用选项："{ref_opt["text"]}"，请在问卷网系统中确认引用设置是否正确。已自动忽略该题的选项数量和文本差异检查'
                })
            # 该题包含引用选项，跳过剩余选项检查（数量和文本）
            continue
        
        doc_opts = {opt['num']: opt for opt in doc_normal_opts}
        excel_opts = {opt['num']: opt for opt in excel_opts_raw}
        
        # 检查普通选项数量
        if len(doc_opts) != len(excel_opts):
            issues.append({
                'level': 'ERROR',
                'type': '选项数量不一致',
                'question': q_id,
                'message': f'文档有 {len(doc_opts)} 个选项，录入有 {len(excel_opts)} 个选项'
            })
        
        # 检查选项编号连续性
        excel_nums = sorted([int(opt['num']) for opt in excel_opts_raw if opt['num'].isdigit()])
        if excel_nums:
            expected_range = list(range(min(excel_nums), max(excel_nums) + 1))
            missing_nums = set(expected_range) - set(excel_nums)
            if missing_nums:
                issues.append({
                    'level': 'ERROR',
                    'type': '选项编号不连续',
                    'question': q_id,
                    'message': f'缺少选项编号: {sorted(missing_nums)}'
                })
        
        # 检查选项内容差异
        for opt_num in set(doc_opts.keys()) & set(excel_opts.keys()):
            doc_text = doc_opts[opt_num]['text'].strip()
            excel_text = excel_opts[opt_num]['text'].strip()
            
            # 简化比较：移除HTML标签和多余空格
            doc_text_clean = re.sub(r'<[^>]+>', '', doc_text).replace(' ', '')
            excel_text_clean = re.sub(r'<[^>]+>', '', excel_text).replace(' ', '')
            
            if doc_text_clean != excel_text_clean:
                issues.append({
                    'level': 'WARNING',
                    'type': '选项文字差异',
                    'question': q_id,
                    'option': opt_num,
                    'message': f'选项{opt_num}文字可能不一致',
                    'doc': doc_text[:50],
                    'excel': excel_text[:50]
                })
        
        # 检查文档有但录入没有的选项
        doc_only = set(doc_opts.keys()) - set(excel_opts.keys())
        if doc_only:
            issues.append({
                'level': 'ERROR',
                'type': '选项缺失',
                'question': q_id,
                'message': f'文档中的选项 {sorted(doc_only)} 在录入中缺失'
            })
    
    return issues


def generate_report(doc_url: str, excel_path: str, issues: List[Dict]) -> Dict:
    """生成检查报告"""
    error_count = sum(1 for i in issues if i['level'] == 'ERROR')
    warning_count = sum(1 for i in issues if i['level'] == 'WARNING')
    info_count = sum(1 for i in issues if i['level'] == 'INFO')
    
    report = {
        'source': {
            'questionnaire_doc': doc_url,
            'excel_file': excel_path
        },
        'summary': {
            'total_issues': len(issues),
            'errors': error_count,
            'warnings': warning_count,
            'infos': info_count,
            'status': 'PASS' if error_count == 0 else 'FAIL'
        },
        'issues': issues
    }
    
    return report


def main():
    if len(sys.argv) < 3:
        print("用法: python3 check_questionnaire.py <问卷文档链接> <录入文件.xlsx>")
        print("\n示例:")
        print("  python3 check_questionnaire.py 'https://docs.corp.kuaishou.com/d/home/xxx' questionnaire.xlsx")
        sys.exit(1)
    
    doc_url = sys.argv[1]
    excel_path = sys.argv[2]
    
    print(f"正在检查问卷录入...")
    print(f"文档: {doc_url}")
    print(f"Excel: {excel_path}")
    print("-" * 50)
    
    # 读取问卷文档
    print("[1/3] 读取问卷文档...")
    doc_content = call_docs_api(doc_url)
    doc_questions = parse_doc_content(doc_content)
    print(f"      发现 {len(doc_questions)} 道题目")
    
    # 读取Excel
    print("[2/3] 读取录入文件...")
    excel_questions = parse_excel(excel_path)
    print(f"      发现 {len(excel_questions)} 道题目")
    
    # 检查
    print("[3/3] 对比检查...")
    issues = check_questions(doc_questions, excel_questions)
    
    # 生成报告
    report = generate_report(doc_url, excel_path, issues)
    
    # 输出结果
    print("\n" + "=" * 50)
    print("检查报告")
    print("=" * 50)
    print(f"状态: {'✅ 通过' if report['summary']['status'] == 'PASS' else '❌ 失败'}")
    print(f"问题总数: {report['summary']['total_issues']}")
    print(f"  - 错误: {report['summary']['errors']}")
    print(f"  - 警告: {report['summary']['warnings']}")
    if report['summary'].get('infos', 0) > 0:
        print(f"  - 提示: {report['summary']['infos']}")
    
    # 分离不同级别的问题
    errors = [i for i in issues if i['level'] == 'ERROR']
    warnings = [i for i in issues if i['level'] == 'WARNING']
    infos = [i for i in issues if i['level'] == 'INFO']
    
    if errors:
        print("\n🔴 错误列表 (必须修复):")
        print("-" * 50)
        for i, issue in enumerate(errors, 1):
            print(f"\n[{i}] {issue['type']}")
            print(f"    题目: {issue['question']}")
            print(f"    描述: {issue['message']}")
            if 'doc' in issue:
                print(f"    文档: {issue['doc']}")
            if 'excel' in issue:
                print(f"    录入: {issue['excel']}")
    
    if warnings:
        print("\n🟡 警告列表 (建议确认):")
        print("-" * 50)
        for i, issue in enumerate(warnings, 1):
            print(f"\n[{i}] {issue['type']}")
            print(f"    题目: {issue['question']}")
            print(f"    描述: {issue['message']}")
            if 'doc' in issue:
                print(f"    文档: {issue['doc']}")
            if 'excel' in issue:
                print(f"    录入: {issue['excel']}")
    
    if infos:
        print("\n💡 提示列表 (需人工确认):")
        print("-" * 50)
        for i, issue in enumerate(infos, 1):
            print(f"\n[{i}] {issue['type']}")
            print(f"    题目: {issue['question']}")
            if issue.get('option'):
                print(f"    选项: {issue['option']}")
            print(f"    描述: {issue['message']}")
    
    if not issues:
        print("\n✅ 未发现任何问题！")
    
    # 输出JSON格式的完整报告
    print("\n" + "=" * 50)
    print("JSON格式报告 (可用于程序化分析):")
    print("=" * 50)
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()