#!/usr/bin/env python3
"""
Cross-analysis helper script for survey data tables.
Parses table structure and extracts data with significance markers.
"""

import json
import re
import sys
from typing import Dict, List, Tuple, Optional

def parse_significance(value_str: str) -> Tuple[float, List[str]]:
    """
    Parse a cell value to extract percentage and significance markers.
    
    Args:
        value_str: Cell value like "45.1%" or "45.1%    B" or "45.1%    C D"
    
    Returns:
        Tuple of (percentage, list_of_markers)
    """
    if not value_str or value_str == "-":
        return 0.0, []
    
    # Pattern: percentage followed by optional markers
    # Examples: "45.1%", "45.1%    B", "45.1%    C D", "45.1%\n    A B"
    pattern = r'([\d.]+)%\s*(?:\n\s*)?([A-Z\s]*)'
    match = re.search(pattern, value_str)
    
    if match:
        percentage = float(match.group(1))
        markers_str = match.group(2).strip() if match.group(2) else ""
        markers = markers_str.split() if markers_str else []
        return percentage, markers
    
    # Try to extract just percentage
    percent_match = re.search(r'([\d.]+)%', value_str)
    if percent_match:
        return float(percent_match.group(1)), []
    
    return 0.0, []


def format_analysis_result(
    question: str,
    dimension: str,
    groups: List[str],
    data: Dict[str, Dict[str, Tuple[float, List[str]]]],
    sample_sizes: Dict[str, int]
) -> str:
    """
    Format analysis results with proper significance interpretation.
    
    Args:
        question: Question text
        dimension: Dimension name
        groups: List of group names with letters (e.g., ["18-30岁(B)", "31-50岁(C)"])
        data: Dict mapping option -> group -> (percentage, markers)
        sample_sizes: Dict mapping group -> sample size
    
    Returns:
        Formatted markdown string
    """
    lines = []
    lines.append(f"## 📊 {question} × {dimension} 分析\n")
    
    # Sample distribution
    lines.append("### 样本分布")
    lines.append("| 分组 | 样本量 | 占比 |")
    lines.append("|------|--------|------|")
    total = sum(sample_sizes.values())
    for group in groups:
        group_name = group.split("(")[0] if "(" in group else group
        letter = group.split("(")[1].rstrip(")") if "(" in group else ""
        n = sample_sizes.get(group_name, 0)
        pct = n / total * 100 if total > 0 else 0
        lines.append(f"| {group} | {n} | {pct:.1f}% |")
    lines.append(f"| **总计** | {total} | 100% |\n")
    
    # Data table
    lines.append("### 各选项分布对比")
    header = "| 选项 | " + " | ".join(groups) + " |"
    lines.append(header)
    lines.append("|" + "|".join(["-" * 10 for _ in range(len(groups) + 1)]) + "|")
    
    for option, group_data in data.items():
        row = [option[:20]]  # Truncate long option names
        for group in groups:
            group_name = group.split("(")[0] if "(" in group else group
            pct, markers = group_data.get(group_name, (0.0, []))
            marker_str = f" {' '.join(markers)}" if markers else ""
            row.append(f"{pct:.1f}%{marker_str}")
        lines.append("| " + " | ".join(row) + " |")
    lines.append("")
    
    # Significant differences
    lines.append("### ✅ 统计显著差异")
    significant_found = False
    
    for option, group_data in data.items():
        for group in groups:
            group_name = group.split("(")[0] if "(" in group else group
            pct, markers = group_data.get(group_name, (0.0, []))
            if markers:
                significant_found = True
                marker_list = ", ".join([f"{m}组" for m in markers])
                lines.append(f"- **{option}**：{group_name}({pct:.1f}%) 显著高于/低于 {marker_list}")
    
    if not significant_found:
        lines.append("- 未发现统计显著差异")
    lines.append("")
    
    # Descriptive observations (top 3 differences without significance)
    lines.append("### ⚠️ 描述性观察（未达统计显著）")
    differences = []
    
    for option, group_data in data.items():
        values = [(group.split("(")[0] if "(" in group else group, 
                   group_data.get(group.split("(")[0] if "(" in group else group, (0.0, []))[0])
                  for group in groups]
        values.sort(key=lambda x: x[1], reverse=True)
        
        if len(values) >= 2 and values[0][1] > values[-1][1]:
            diff = values[0][1] - values[-1][1]
            differences.append((option, values[0][0], values[0][1], values[-1][0], values[-1][1], diff))
    
    differences.sort(key=lambda x: x[5], reverse=True)
    
    for option, max_group, max_val, min_group, min_val, diff in differences[:3]:
        lines.append(f"- **{option}**：{max_group}({max_val:.1f}%) > {min_group}({min_val:.1f}%)，差值{diff:.1f}个百分点（未标注显著性）")
    
    if not differences:
        lines.append("- 各组分布较为均匀")
    
    return "\n".join(lines)


def extract_structure_from_api_response(response: dict) -> Tuple[List[Dict], List[Dict]]:
    """
    Extract dimensions and questions from API response.
    
    Returns:
        Tuple of (dimensions, questions)
    """
    dimensions = []
    questions = []
    
    rows = response.get("rows", [])
    
    # Parse header rows to find dimensions
    # This is a simplified parser - real implementation would be more robust
    for row in rows[:5]:  # Check first few rows for headers
        for cell in row:
            value = cell.get("showValue", "")
            # Look for dimension indicators
            if any(keyword in value for keyword in ["年龄", "性别", "城市", "活跃", "平台"]):
                if value not in [d["name"] for d in dimensions]:
                    dimensions.append({
                        "name": value,
                        "row_index": cell.get("rowIndex"),
                        "col_index": cell.get("columnIndex")
                    })
    
    # Parse question rows
    for row in rows:
        for cell in row:
            value = cell.get("showValue", "")
            # Look for question codes like A1, A7_1, B2, etc.
            if re.match(r'^[A-Z]\d', value) and len(value) < 100:
                if value not in [q["code"] for q in questions]:
                    questions.append({
                        "code": value[:10],  # Truncate to code part
                        "text": value,
                        "row_index": cell.get("rowIndex"),
                        "col_index": cell.get("columnIndex")
                    })
    
    return dimensions, questions


if __name__ == "__main__":
    # Example usage
    if len(sys.argv) < 2:
        print("Usage: analyze_table.py <command> [args]")
        print("Commands: parse, format")
        sys.exit(1)
    
    command = sys.argv[1]
    
    if command == "parse":
        # Parse a cell value
        value = sys.argv[2] if len(sys.argv) > 2 else "45.1%    B"
        pct, markers = parse_significance(value)
        print(f"Value: {value}")
        print(f"Percentage: {pct}%")
        print(f"Markers: {markers}")
    
    elif command == "format":
        # Example formatting
        groups = ["18-30岁(B)", "31-50岁(C)", "50+岁(D)"]
        data = {
            "任务简单": {
                "18-30岁": (63.5, ["C", "D"]),
                "31-50岁": (44.0, []),
                "50+岁": (39.9, [])
            },
            "奖励满意": {
                "18-30岁": (40.5, []),
                "31-50岁": (33.5, []),
                "50+岁": (35.1, [])
            }
        }
        sample_sizes = {"18-30岁": 124, "31-50岁": 266, "50+岁": 78}
        
        result = format_analysis_result(
            "A7_1 体验好的原因",
            "年龄组",
            groups,
            data,
            sample_sizes
        )
        print(result)