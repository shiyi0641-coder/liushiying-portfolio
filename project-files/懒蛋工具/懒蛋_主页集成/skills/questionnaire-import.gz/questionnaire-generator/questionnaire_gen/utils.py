"""工具函数"""
import re
from typing import Dict, Tuple


def parse_option_tags(text: str) -> Tuple[str, Dict[str, bool], str]:
    """解析选项中的标记如【开放，固定，排他】或[置底,排他]
    
    支持中文括号【】和英文括号[]
    
    Returns:
        (清理后的文本, 标记字典, 分组代码)
    """
    tags = {'is_open': False, 'is_fixed': False, 'is_exclusive': False}
    group_code = ""
    
    # 处理中文括号【】
    for match in re.findall(r'【([^】]+)】', text):
        match_lower = match.lower()
        if '开放' in match_lower:
            tags['is_open'] = True
        if '固定' in match_lower or '置底' in match_lower:
            tags['is_fixed'] = True
        if '排他' in match_lower or '互斥' in match_lower:
            tags['is_exclusive'] = True
        if match.startswith('O[') or '##' in match:
            group_code = match.strip()
    
    # 处理英文括号[]
    for match in re.findall(r'\[([^\]]+)\]', text):
        match_lower = match.lower()
        if '开放' in match_lower:
            tags['is_open'] = True
        if '固定' in match_lower or '置底' in match_lower:
            tags['is_fixed'] = True
        if '排他' in match_lower or '互斥' in match_lower:
            tags['is_exclusive'] = True
    
    # 清理所有括号标记
    clean_text = re.sub(r'【[^】]+】', '', text).strip()
    clean_text = re.sub(r'\[[^\]]+\]', '', clean_text).strip()
    return clean_text, tags, group_code


def build_option_type_tags(option) -> str:
    """根据选项标记构建题型列显示内容 [开放][固定][排它]"""
    tags = []
    if option.is_open:
        tags.append("[开放]")
    if option.is_fixed:
        tags.append("[固定]")
    if option.is_exclusive:
        tags.append("[排它]")
    return "".join(tags)


def detect_question_type(title: str) -> str:
    """从题干中检测题型"""
    t = title.lower()
    
    type_keywords = [
        ('多选', ['多选', '可多选', '可多選']),
        ('单选', ['单选', '單選']),
        ('矩单', ['矩阵单选', '矩单']),
        ('矩多', ['矩阵多选', '矩多']),
        ('矩分', ['矩阵打分', '矩分']),
        ('矩空', ['矩阵填空', '矩空']),
        ('填空', ['填空']),
        ('打分', ['打分', '评分']),
    ]
    
    for qtype, keywords in type_keywords:
        if any(k in t for k in keywords):
            return qtype
    
    return "单选"


def clean_question_title(title: str) -> str:
    """清理题干中的题型标注和多余内容"""
    # 移除【】标签（如【主用平台】）
    title = re.sub(r'【[^】]+】', '', title)
    # 移除题型标注
    title = re.sub(r'[（(]\s*(?:单选|多选|填空|打分)(?:题)?\s*[）)]', '', title)
    # 移除"可多选"标注
    title = re.sub(r'[（(][^）)]*可多选[^）)]*[）)]', '', title)
    # 规范化空格
    title = re.sub(r'\s+', ' ', title).strip()
    return title


def should_skip_option(text: str) -> bool:
    """判断选项是否应该被跳过"""
    if not text:
        return True
    # 【主用平台】纯标记
    if re.match(r'^【[^】]+】$', text):
        return True
    # [分类] 纯标记
    if re.match(r'^\[[^\]]+\]$', text):
        return True
    # --分类-- 格式（如 --签到类--, --金币回收类--（需要配图，见评论））
    if re.match(r'^[—–\-]{2,}[^—–\-]+[—–\-]{2,}', text):
        return True
    # -不知道- 格式
    if re.match(r'^-[^-]+-$', text):
        return True
    # #XXX 标题
    if re.match(r'^#\s*\S', text):
        return True
    # 结束语
    end_keywords = ['调查已完成', '非常感谢您的参与', '谢谢您的参与', '调查已结束']
    if any(kw in text for kw in end_keywords):
        return True
    return False


def has_end_survey_keyword(text: str) -> bool:
    """检测是否包含结束调研关键词"""
    keywords = ['结束填答', '废卷', '结束调研', '答题结束', '被筛选']
    return any(kw in text for kw in keywords)
