"""Excel 文件生成器"""
from typing import List

from .models import Question, Option, QuestionGroup
from .utils import build_option_type_tags


def generate_wenjuanwang_excel(questions: List[Question], groups: List[QuestionGroup], output_path: str):
    """生成问卷网格式的 Excel 文件"""
    try:
        import pandas as pd
    except ImportError:
        raise Exception("需要安装 pandas: pip install pandas openpyxl")
    
    # 构建题目列表
    question_rows = _build_question_rows(questions)
    
    # 构建分组列表
    group_rows = _build_group_rows(groups)
    
    # 创建 Excel
    with pd.ExcelWriter(output_path, engine='openpyxl') as writer:
        # 题目工作表
        df_questions = pd.DataFrame(question_rows)
        df_questions.to_excel(writer, sheet_name='Sheet1', index=False, header=False)
        
        # 分组工作表
        if group_rows:
            df_groups = pd.DataFrame(group_rows)
            df_groups.to_excel(writer, sheet_name='QGroup', index=False, header=False)
    
    return output_path


def _build_question_rows(questions: List[Question]) -> List[List]:
    """构建题目行数据"""
    rows = []
    
    for q in questions:
        # 题目行
        rows.append([
            q.id,                                    # A: 题号
            q.title,                                 # B: 题干
            q.q_type,                                # C: 题型
            q.display_code,                          # D: 显示代码
            q.jump_code.strip(),                     # E: 跳转代码
            q.group_code,                            # F: 分组代码
            ""                                       # G: 自动勾选
        ])
        
        # 矩阵题特殊处理
        if q.is_matrix and q.matrix_cols:
            # 矩阵列分值行（C列开始）
            col_scores = ['', '']  # A、B列空
            col_scores.extend([str(i) for i in range(len(q.matrix_cols), 0, -1)])  # 倒序排列分值
            rows.append(col_scores)
            
            # 矩阵列标签行（C列开始）
            col_labels = ['', '']  # A、B列空
            col_labels.extend(q.matrix_cols)
            rows.append(col_labels)
            
            # 矩阵行
            for idx, row_text in enumerate(q.matrix_rows, 1):
                rows.append([
                    idx,                             # A: 行号
                    row_text,                        # B: 行标题
                    '', '', '', '', ''              # C-G: 空
                ])
        else:
            # 普通选项行
            for opt in q.options:
                type_tags = build_option_type_tags(opt)
                jump = opt.jump_code if opt.jump_code else ""
                
                rows.append([
                    opt.num,                         # A: 选项号
                    opt.text,                        # B: 选项文字
                    type_tags,                       # C: 类型标记
                    opt.display_code,                # D: 显示代码
                    jump,                            # E: 跳转代码
                    opt.group_code,                  # F: 分组代码
                    opt.auto_check                   # G: 自动勾选
                ])
        
        # 空行分隔
        rows.append([''] * 7)
    
    return rows


def _build_group_rows(groups: List[QuestionGroup]) -> List[List]:
    """构建分组行数据 - 3列：分组ID、分组名称、包含题目"""
    if not groups:
        return []
    
    rows = []
    for g in groups:
        # 3列：分组ID、分组名称、包含题目
        rows.append([g.group_id, g.name, g.questions])
    
    return rows
