"""主入口 - 整合所有功能"""
import re
from typing import List, Tuple, Optional

from .models import Question, QuestionGroup
from .markdown_parser import parse_markdown_content
from .group_manager import (
    detect_split_questionnaires,
    detect_groups_from_content,
    build_matrix_groups,
    filter_questions_by_split,
    filter_groups_by_questions
)
from .excel_writer import generate_wenjuanwang_excel


def parse_doc_content(content: str) -> Tuple[List[Question], List[QuestionGroup]]:
    """解析文档内容，返回题目列表和分组列表
    
    注意：QGroup 只包含 Part 分组（如竞对行为及体验），不包含矩阵分组
    矩阵分组（如A3矩阵行/列）不需要放入 QGroup
    """
    
    # 1. 解析 Markdown 内容
    questions = parse_markdown_content(content)
    
    # 2. 检测分组（只包含 Part 分组，不包含矩阵分组）
    groups = detect_groups_from_content(content, questions)
    
    return questions, groups


def generate_split_questionnaires(content: str, base_output_path: str) -> List[str]:
    """生成拆分问卷，返回生成的文件列表
    
    基于行号范围精确划分题目，不依赖 Part 标题：
    1. 检测所有拆分标记，记录每个拆分的起始行和结束行
    2. 遍历题目时直接判断行号属于哪个拆分的范围
    3. 每个题目只会被分配到一个拆分（按行号范围）
    """
    
    # 解析文档
    all_questions, all_groups = parse_doc_content(content)
    
    # 检测拆分配置，返回 (start_line, end_line, split_id, description)
    splits = detect_split_questionnaires(content)
    
    if not splits:
        # 无拆分，生成单个文件
        generate_wenjuanwang_excel(all_questions, all_groups, base_output_path)
        return [base_output_path]
    
    # 按行号范围分配题目到各个拆分
    # 每个拆分的范围是 [start_line, end_line)，左闭右开
    for q in all_questions:
        q.split_ids = []
        q_line = q.line_number
        
        # 找到题目所属的拆分（根据行号范围）
        for start_line, end_line, split_id, description in splits:
            if start_line <= q_line < end_line:
                q.split_ids.append(split_id)
                break  # 一个题目只属于一个拆分（按行号范围精确划分）
    
    # 生成每个拆分的文件
    output_files = []
    base_name = base_output_path.replace('.xlsx', '')
    
    for start_line, end_line, split_id, description in splits:
        split_questions = filter_questions_by_split(all_questions, split_id)
        split_groups = filter_groups_by_questions(all_groups, split_questions)
        
        # 使用描述名称作为文件名，如果描述就是ID则使用默认命名
        if description == split_id:
            output_path = f"{base_name}_{split_id}.xlsx"
        else:
            # 清理描述名称中的非法字符
            safe_desc = re.sub(r'[\\/*?:"<>|]', '', description)
            output_path = f"{base_name}_{safe_desc}.xlsx"
        
        generate_wenjuanwang_excel(split_questions, split_groups, output_path)
        output_files.append(output_path)
    
    return output_files


def generate_filename_from_content(content: str, questions: List[Question]) -> str:
    """从内容生成文件名"""
    # 尝试从文档标题提取
    m = re.search(r'^#\s+(.+)$', content, re.MULTILINE)
    if m:
        title = m.group(1).strip()
        title = re.sub(r'[\\/*?:"<>|]', '', title)
        return f"{title}.xlsx"
    
    # 默认名称
    return "问卷导入.xlsx"
