"""分组和拆分问卷处理"""
import re
from typing import List, Tuple, Dict

from .models import Question, QuestionGroup


def detect_split_questionnaires(content: str) -> List[Tuple[int, int, str, str]]:
    """检测拆分问卷配置，返回每个拆分的行号范围
    
    Returns:
        [(起始行号, 结束行号, 拆分ID, 描述名称), ...]
        结束行号是排他的（最后一个拆分的结束行为文档总行数）
    """
    lines = content.split('\n')
    
    # 找到所有拆分标记位置
    split_positions = []
    for i, line in enumerate(lines):
        # 匹配"# 拆分-问卷1-通用用户"格式，提取ID和描述
        m = re.search(r'拆分[\-–—](问卷\d+|版本\d+|分组\d+)[\-–—]\s*(.+)', line)
        if m:
            split_id = m.group(1)
            # 清理描述名称（移除括号内容）
            description = re.sub(r'[（(].*?[）)]', '', m.group(2)).strip()
            split_positions.append((i, split_id, description))
        else:
            # 简化格式：只提取ID
            m = re.search(r'拆分[\-–—](问卷\d+|版本\d+|分组\d+)[\-–—]', line)
            if m:
                split_id = m.group(1)
                split_positions.append((i, split_id, split_id))
    
    if not split_positions:
        return []
    
    # 构建每个拆分的行号范围
    splits = []
    total_lines = len(lines)
    
    for idx, (start_line, split_id, description) in enumerate(split_positions):
        # 确定结束位置（下一个拆分的开始或文档末尾）
        end_line = split_positions[idx + 1][0] if idx + 1 < len(split_positions) else total_lines
        
        splits.append((start_line, end_line, split_id, description))
    
    return splits


def detect_groups_from_content(content: str, questions: List[Question]) -> List[QuestionGroup]:
    """从文档内容中检测分组"""
    groups = []
    lines = content.split('\n')
    
    # 查找 Part/章节标题
    for i, line in enumerate(lines):
        line_stripped = line.strip()
        
        # 匹配 "## Part1. XXX" 或 "Part1. XXX"
        m = re.match(r'^#{0,4}\s*Part(\d+)[:.\s]+(.+)$', line_stripped, re.IGNORECASE)
        if m:
            part_num = int(m.group(1))
            group_name = m.group(2).strip()
            
            # 确定该分组的题号前缀
            prefix_map = {1: 'A', 2: 'B', 3: 'C', 4: 'D', 5: 'E'}
            prefix = prefix_map.get(part_num, chr(64 + part_num))
            
            # 收集该分组的题目（支持 A1, A2_1, B6a, B15b 等格式）
            group_questions = [q.id for q in questions if q.id.startswith(prefix)]
            # 按题号排序
            group_questions.sort()
            
            if group_questions:
                groups.append(QuestionGroup(
                    group_id=f"G{part_num}",
                    name=group_name,
                    questions=','.join(group_questions)
                ))
    
    # 如果没有找到 Part 标题，按题号前缀自动分组
    if not groups:
        groups = _auto_group_by_prefix(questions)
    
    return groups


def _auto_group_by_prefix(questions: List[Question]) -> List[QuestionGroup]:
    """按题号前缀自动分组"""
    prefix_map: Dict[str, List[str]] = {}
    
    for q in questions:
        prefix = q.id[0] if q.id else 'Z'
        if prefix not in prefix_map:
            prefix_map[prefix] = []
        prefix_map[prefix].append(q.id)
    
    groups = []
    for idx, (prefix, qids) in enumerate(sorted(prefix_map.items()), 1):
        # 按自然顺序排序题号
        qids.sort()
        groups.append(QuestionGroup(
            group_id=f"G{idx}",
            name=f"{prefix}部分",
            questions=','.join(qids)
        ))
    
    return groups


def build_matrix_groups(questions: List[Question]) -> List[QuestionGroup]:
    """为矩阵题构建分组"""
    groups = []
    
    for q in questions:
        if q.is_matrix and q.matrix_rows:
            # 矩阵行分组
            groups.append(QuestionGroup(
                group_id="G1",
                name=f"{q.id}矩阵行",
                questions=q.id,
                group_type="矩阵行",
                dimension_items=q.matrix_rows
            ))
            
            # 矩阵列分组
            if q.matrix_cols:
                groups.append(QuestionGroup(
                    group_id="G2",
                    name=f"{q.id}矩阵列",
                    questions=q.id,
                    group_type="矩阵列",
                    dimension_items=q.matrix_cols
                ))
    
    return groups


def filter_questions_by_split(questions: List[Question], split_id: str) -> List[Question]:
    """根据拆分ID筛选题目"""
    return [q for q in questions if split_id in q.split_ids]


def filter_groups_by_questions(groups: List[QuestionGroup], questions: List[Question]) -> List[QuestionGroup]:
    """根据题目列表筛选分组，并去重
    
    只保留非矩阵分组（group_type为空），并按 group_id 去重
    """
    valid_qids = {q.id for q in questions}
    
    seen_ids = set()
    filtered = []
    
    for g in groups:
        # 跳过矩阵分组（QGroup不需要）
        if g.group_type:
            continue
            
        # 去重：同一个 group_id 只保留一次
        if g.group_id in seen_ids:
            continue
        seen_ids.add(g.group_id)
        
        qids = [q.strip() for q in g.questions.split(',')]
        valid = [q for q in qids if q in valid_qids]
        if valid:
            filtered.append(QuestionGroup(
                group_id=g.group_id,
                name=g.name,
                questions=','.join(valid),
                display_code=g.display_code,
                group_type=g.group_type,
                dimension_items=g.dimension_items
            ))
    
    return filtered
