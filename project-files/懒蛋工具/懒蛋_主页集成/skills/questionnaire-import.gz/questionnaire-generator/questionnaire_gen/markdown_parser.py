"""Markdown 格式解析器"""
import re
from typing import List, Dict, Tuple

from .models import Question, Option
from .utils import (
    parse_option_tags, detect_question_type, clean_question_title,
    should_skip_option, has_end_survey_keyword
)
from .logic_converter import convert_logic_to_code


def parse_markdown_content(content: str) -> List[Question]:
    """解析 Markdown 格式的文档内容"""
    questions = []
    lines = content.split('\n')
    
    # 预扫描建立题型映射
    qtype_map = _build_qtype_map(lines)
    
    i = 0
    while i < len(lines):
        line = lines[i].strip()
        
        # 匹配题号行
        qid, title, skip = _match_question_line(line, lines, i)
        if not qid:
            i += 1
            continue
        
        if skip:
            i = skip
            continue
        
        q_type = detect_question_type(title)
        
        # 提取逻辑说明
        title, display_code = _extract_logic(title, qtype_map)
        title = clean_question_title(title)
        
        if not title:
            i += 1
            continue
        
        # 创建题目，记录行号
        question = Question(
            id=qid, title=title, q_type=q_type,
            options=[], display_code=display_code,
            line_number=i
        )
        
        # 解析选项
        i, question = _parse_options(i + 1, lines, question, qid, q_type, questions)
        
        if question.options or q_type == "填空" or question.is_matrix or q_type == "打分":
            questions.append(question)
    
    # 处理"同XX"引用
    _resolve_option_references(questions)
    
    # 处理"只选中一个"逻辑（需要先知道选项数量）
    _resolve_select_one_logic(questions)
    
    return questions


def _build_qtype_map(lines: List[str]) -> Dict[str, str]:
    """预扫描建立题型映射"""
    qtype_map = {}
    # 支持格式: A1, A2_1, Ba1, B6a, B15b (大写字母+可选小写字母+数字+可选小写字母+可选_数字)
    qid_pattern = r'[A-Z][a-z]?\d+[a-z]?(?:_\d+)?'
    patterns = [
        # A3.【标题】内容 格式
        rf'^({qid_pattern})[\.。]\s*【[^】]+】\s*(.+)',
        rf'^[#]*\s*({qid_pattern})[\.。]\s*(.+)',
        rf'【({qid_pattern})】\s*【([^】]+)】',
        rf'^({qid_pattern})[\.。]\s*(.+)',
    ]
    
    for line in lines:
        line_stripped = line.strip()
        for pattern in patterns:
            m = re.match(pattern, line_stripped)
            if m:
                qid = m.group(1)
                title = m.group(2) if len(m.groups()) >= 2 else line_stripped
                qtype_map[qid] = detect_question_type(title)
                break
    
    return qtype_map


def _match_question_line(line: str, lines: List[str], idx: int) -> Tuple[str, str, int]:
    """匹配题号行，返回 (qid, title, 新索引或None)"""
    # 题号格式: A1, A2_1, Ba1, B6a, B15b (大写字母+可选小写字母+数字+可选小写字母+可选_数字)
    qid_pattern = r'[A-Z][a-z]?\d+[a-z]?(?:_\d+)?'
    patterns = [
        # A3.【标题】内容 格式
        (rf'^({qid_pattern})[\.。]\s*【[^】]+】\s*(.+)$', 2),
        (rf'^[#]+\s*({qid_pattern})[\.。]\s*(.+)$', 2),
        (rf'^({qid_pattern})[\.。]\s*(.+)$', 2),
        (rf'【({qid_pattern})】\s*【([^】]+)】\s*(.+)$', 3),
        (rf'^[#]*\s*({qid_pattern})[:：]\s*(.+)$', 2),
        (rf'^[#]*\s*({qid_pattern})\s*([（(][^）)]+[）)])(.+)$', 3),
        (rf'^[#]*\s*({qid_pattern})\s*([（(][^）)]+[）)])$', 2),
    ]
    
    for pattern, group_count in patterns:
        m = re.match(pattern, line)
        if m:
            qid = m.group(1)
            title = ""
            
            if group_count == 3 and len(m.groups()) >= 3 and m.group(3):
                title = m.group(3)
            elif group_count >= 2:
                title = m.group(2)
            
            # 处理只有逻辑说明的情况
            if re.match(r'^[（(][^）)]+[）)]$', title.strip()):
                if idx + 1 < len(lines):
                    return qid, lines[idx + 1].strip(), idx + 2
                return qid, "", None
            
            return qid, title, None
    
    return None, None, None


def _extract_logic(title: str, qtype_map: Dict[str, str]) -> Tuple[str, str]:
    """从标题中提取逻辑说明"""
    display_code = ""
    # 题号格式: A1, A2_1, Ba1, B6a, B15b (大写字母+可选小写字母+数字+可选小写字母+可选_数字)
    qid_pattern = r'[A-Z][a-z]?\d+[a-z]?(?:_\d+)?'
    
    # （当A1=2）格式
    m = re.search(r'[（(](当[^）)]+)[）)]', title)
    if m:
        display_code = convert_logic_to_code(m.group(1), "", qtype_map)
        title = re.sub(r'[（(]当[^）)]+[）)]', '', title)
    
    # （A1=2/3）格式
    m = re.search(rf'[（(]({qid_pattern}[=<>!≠][^）)]+)[）)]', title)
    if m and not display_code:
        display_code = convert_logic_to_code(m.group(1), "", qtype_map)
        title = re.sub(rf'[（(]{qid_pattern}[=<>!≠][^）)]+[）)]', '', title)
    
    # A5_1<=4 格式（标题末尾的逻辑说明，无括号）
    # 匹配题目编号_行号+比较符+数字，如 A5_1<=4, A5_2<=4, B3=1
    # 支持紧跟在内容后或有空格，如【可多选】A5_1<=4 或 内容 A5_1<=4
    m = re.search(rf'(?:【[^】]+】)?\s*({qid_pattern}(?:<=?|>=?|=|<>|!=|≠)\d+)$', title)
    if m and not display_code:
        display_code = convert_logic_to_code(m.group(1), "", qtype_map)
        title = re.sub(rf'(?:【[^】]+】)?\s*{qid_pattern}(?:<=?|>=?|=|<>|!=|≠)\d+$', '', title)
    
    # A1只选中一个则... 使用占位符，后续根据选项数量生成
    m = re.search(rf'({qid_pattern})\s*只选中一个则', title)
    if m:
        # 使用特殊占位符格式 __SELECT_ONE_{qid}__，后续会替换为实际代码
        display_code = f"__SELECT_ONE_{m.group(1)}__"
        title = re.sub(rf'{qid_pattern}\s*只选中一个则[^\n]*', '', title)
    
    return title, display_code


def _parse_options(start_idx: int, lines: List[str], question: Question, 
                   qid: str, q_type: str, all_questions: List[Question]) -> Tuple[int, Question]:
    """解析选项"""
    i = start_idx
    opt_num = 1
    matrix_rows = []
    matrix_cols = []
    in_matrix_rows = False
    in_matrix_cols = False
    # 题号格式: A1, A2_1, Ba1, B6a, B15b (大写字母+可选小写字母+数字+可选小写字母+可选_数字)
    qid_pattern = r'[A-Z][a-z]?\d+[a-z]?(?:_\d+)?'
    
    while i < len(lines):
        opt_line = lines[i].strip()
        
        # 矩阵标记（必须在停止条件之前检查）
        if opt_line in ['--矩阵行--', '——矩阵行——']:
            in_matrix_rows, in_matrix_cols = True, False
            i += 1
            continue
        if opt_line in ['--矩阵列--', '——矩阵列——']:
            in_matrix_rows, in_matrix_cols = False, True
            i += 1
            continue
        
        # 停止条件
        if not opt_line:
            i += 1
            continue
        if re.match(rf'^[#]+\s*{qid_pattern}', opt_line):
            break
        if re.match(rf'^{qid_pattern}[\.。]\s*', opt_line) and not opt_line.startswith(tuple(f'{n}.' for n in range(10))):
            break
        if re.match(r'^#{1,6}\s*[—–\-]', opt_line) or re.match(r'^[—–\-]{2,}$', opt_line):
            break
        
        # 跳过选项分类标记（如 --签到类--）
        if re.match(r'^[—–\-]{2,}[^—–\-]+[—–\-]{2,}$', opt_line):
            i += 1
            continue
        
        # 收集矩阵内容
        if in_matrix_rows and opt_line:
            if re.match(rf'^#{1,6}\s+{qid_pattern}', opt_line):
                break
            text, _, _ = parse_option_tags(opt_line)
            if text:
                # 检测引用格式：引用A1、引用 A1
                m = re.match(rf'^引用\s*({qid_pattern})$', text)
                if m:
                    question.matrix_row_ref = m.group(1)
                else:
                    matrix_rows.append(text)
            i += 1
            continue
        
        if in_matrix_cols and opt_line:
            if re.match(rf'^#{1,6}\s+{qid_pattern}', opt_line):
                break
            text, _, _ = parse_option_tags(opt_line)
            if text:
                matrix_cols.append(text)
            i += 1
            continue
        
        # 跳过选项分类标记（如 --签到类--, --金币回收类--（需要配图，见评论））
        if re.match(r'^[—–\-]{2,}[^—–\-]+[—–\-]{2,}', opt_line):
            i += 1
            continue
        
        # 解析普通选项
        opt_text = re.sub(r'^[-*•\d.．]\s*', '', opt_line)
        
        # 检测跳转
        jump_target = None
        m = re.search(rf'[\-–—]?(?:跳转|跳)\s*({qid_pattern})', opt_text)
        if m:
            jump_target = m.group(1)
            opt_text = re.sub(rf'[\-–—]?(?:跳转|跳)\s*{qid_pattern}', '', opt_text)
        
        # 检测结束关键词
        if has_end_survey_keyword(opt_text):
            jump_target = "END"
            for kw in ['结束填答', '废卷', '结束调研', '答题结束', '被筛选']:
                opt_text = opt_text.replace(kw, '')
        
        # 清理标记
        clean_text, tags, _ = parse_option_tags(opt_text)
        clean_text = clean_text.strip('，,、 ')
        
        # 跳过特殊选项
        if should_skip_option(clean_text) or clean_text in ['选项', '题号']:
            i += 1
            continue
        
        # 收集跳转
        if jump_target:
            condition = f"Q.{qid}.select().{'include' if q_type == '多选' else 'isin'}({opt_num})"
            if jump_target == "END":
                question.jump_code += f"if( {condition} ) {{ next = '2' }} "
            else:
                question.jump_code += f"if( {condition} ) {{ next = '{jump_target}' }} "
        
        # 添加选项
        question.options.append(Option(
            num=opt_num, text=clean_text,
            is_open=tags['is_open'], is_fixed=tags['is_fixed'],
            is_exclusive=tags['is_exclusive']
        ))
        
        opt_num += 1
        i += 1
    
    # 处理矩阵题
    if matrix_rows or matrix_cols:
        question.is_matrix = True
        question.matrix_rows = matrix_rows
        question.matrix_cols = matrix_cols
        question.q_type = "矩多" if q_type == "多选" else "矩单"
        for idx, row in enumerate(matrix_rows, 1):
            question.options.append(Option(num=idx, text=row))
    
    return i, question


def _resolve_option_references(questions: List[Question]):
    """处理引用：
    1. 选项中的"同XX"引用
    2. 矩阵行的"引用XX"引用
    """
    qid_map = {q.id: q for q in questions}
    
    # 处理选项中的"同XX"引用和"引用XX"引用
    for q in questions:
        for opt in q.options:
            # 匹配 "同XX" 或 "引用XX" 格式
            m = re.search(r'(?:同|引用)\s*([A-Z][a-z]?\d+)', opt.text)
            if m:
                ref_q = qid_map.get(m.group(1))
                if ref_q and ref_q.options:
                    opt.text = "、".join([o.text for o in ref_q.options])
    
    # 处理矩阵行的"引用XX"引用
    for q in questions:
        if q.matrix_row_ref and not q.matrix_rows:
            ref_q = qid_map.get(q.matrix_row_ref)
            if ref_q and ref_q.options:
                # 复制被引用题目的选项文本作为矩阵行
                q.matrix_rows = [o.text for o in ref_q.options]


def _resolve_select_one_logic(questions: List[Question]):
    """处理'只选中一个'逻辑，根据选项数量生成否定所有未选中情况的代码
    
    例如 A1 有10个选项，则生成：
    !(Q.A1.select()==1 || Q.A1.select()==2 || ... || Q.A1.select()==10)
    """
    # 构建 qid_map，对于重复的题目ID，保留选项最多的那个
    qid_map: Dict[str, Question] = {}
    for q in questions:
        if q.id in qid_map:
            # 如果已存在，保留选项更多的那个
            if len(q.options) > len(qid_map[q.id].options):
                qid_map[q.id] = q
        else:
            qid_map[q.id] = q
    
    for q in questions:
        if not q.display_code:
            continue
            
        # 匹配 __SELECT_ONE_{qid}__ 占位符
        m = re.search(r'__SELECT_ONE_([A-Z][a-z]?\d+(?:_\d+)?)__', q.display_code)
        if m:
            ref_qid = m.group(1)
            ref_q = qid_map.get(ref_qid)
            
            if ref_q and ref_q.options:
                # 生成 !(Q.A1.select()==1 || Q.A1.select()==2 || ...)
                option_count = len(ref_q.options)
                conditions = " || ".join([f"Q.{ref_qid}.select()=={i}" for i in range(1, option_count + 1)])
                q.display_code = f"!({conditions})"
            else:
                # 如果找不到引用题目或没有选项，保留占位符并添加注释
                q.display_code = f"// TODO: {ref_qid} 题目未找到或无选项，无法生成'只选中一个'逻辑"
