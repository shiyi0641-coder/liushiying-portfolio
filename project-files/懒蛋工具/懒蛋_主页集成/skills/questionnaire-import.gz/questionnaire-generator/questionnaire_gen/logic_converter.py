"""逻辑代码转换"""
import re
from typing import Dict


def convert_logic_to_code(logic_desc: str, current_qid: str, qtype_map: Dict[str, str]) -> str:
    """将逻辑说明转换为问卷网逻辑代码
    
    支持格式：
    - 当A1=2时出示 -> Q.A1.select().isin(2)
    - A2不选1/2 -> Q.A2.select().notin(1,2) / notinclude
    - B1选中8/9/10 -> Q.B1.select().isin(8,9,10) / include
    - B5=7/8/9/10 (打分题) -> Q.B5.score(1) && Q.B5.score(1)[0].asInt()>6
    """
    logic_desc = logic_desc.strip()
    if not qtype_map:
        qtype_map = {}
    
    # 打分题处理
    score_result = _handle_score_logic(logic_desc, qtype_map)
    if score_result:
        return score_result
    
    # 多题号或: S2=1或S3=1
    m = re.search(r'当?([A-Z][a-z]?\d+(?:_\d+)?)=(\d+)[或,、]([A-Z][a-z]?\d+(?:_\d+)?)=(\d+)', logic_desc)
    if m:
        return f"(Q.{m.group(1)}.select().isin({m.group(2)})) || (Q.{m.group(3)}.select().isin({m.group(4)}))"
    
    # 单条件或: A1=2或3
    m = re.search(r'当?([A-Z][a-z]?\d+(?:_\d+)?)=(\d+)[或,、](\d+)', logic_desc)
    if m:
        return f"Q.{m.group(1)}.select().isin({m.group(2)},{m.group(3)})"
    
    # 范围: B3=2-6
    m = re.search(r'([A-Z][a-z]?\d+(?:_\d+)?)=(\d+)-(\d+)', logic_desc)
    if m:
        vals = ','.join(str(i) for i in range(int(m.group(2)), int(m.group(3)) + 1))
        return f"Q.{m.group(1)}.select().isin({vals})"
    
    # 不等于: B11<>3
    m = re.search(r'([A-Z][a-z]?\d+(?:_\d+)?)(?:<>|!=|≠)(\d+)', logic_desc)
    if m:
        qid, val = m.group(1), m.group(2)
        if qtype_map.get(qid) == "多选":
            return f"Q.{qid}.select().notinclude({val})"
        return f"Q.{qid}.select()!={val}"
    
    # 不选: A2不选1/2
    m = re.search(r'([A-Z][a-z]?\d+(?:_\d+)?)不选([\d/,]+)', logic_desc)
    if m:
        qid, vals = m.group(1), m.group(2).replace('/', ',')
        if qtype_map.get(qid) == "多选":
            return f"Q.{qid}.select().notinclude({vals})"
        return f"Q.{qid}.select().notin({vals})"
    
    # 未选: S2未选2
    m = re.search(r'([A-Z][a-z]?\d+(?:_\d+)?)未选([\d,]+)', logic_desc)
    if m:
        return f"Q.{m.group(1)}.select().notinclude({m.group(2)})"
    
    # 选中: B1选中8/9/10
    m = re.search(r'([A-Z][a-z]?\d+(?:_\d+)?)选中?([\d/_]+)', logic_desc)
    if m:
        qid, vals = m.group(1), m.group(2).replace('/', ',')
        if qtype_map.get(qid) == "多选":
            return f"Q.{qid}.select().include({vals})"
        return f"Q.{qid}.select().isin({vals})"
    
    # 等值: Ba2=1/2/3
    m = re.search(r'([A-Z][a-z]?\d+(?:_\d+)?)=(\d+(?:[,/]\d+)*)', logic_desc)
    if m:
        qid, vals = m.group(1), m.group(2).replace('/', ',')
        # 检查是否是打分题或其父题号是打分题
        parent_qid = qid.split('_')[0] if '_' in qid else qid
        if qtype_map.get(qid) == "打分" or qtype_map.get(parent_qid) == "打分":
            return f"Q.{qid}.score(1) && Q.{qid}.score(1)[0].asInt()=={vals}"
        return f"Q.{qid}.select().isin({vals})"
    
    # 比较: A5_1<=4
    m = re.search(r'([A-Z][a-z]?\d+_[\d]+)(<=?|>=?|=)(\d+)', logic_desc)
    if m:
        qid, op, val = m.group(1), m.group(2), m.group(3)
        # 如果是打分题，使用 score(1) 格式
        if qtype_map.get(qid) == "打分":
            return f"Q.{qid}.score(1) && Q.{qid}.score(1)[0].asInt(){op}{val}"
        # 检查父题号是否是打分题（如 A5_1 的父题号是 A5）
        parent_qid = qid.split('_')[0]
        if qtype_map.get(parent_qid) == "打分":
            return f"Q.{qid}.score(1) && Q.{qid}.score(1)[0].asInt(){op}{val}"
        return f"Q.{qid}.value{op}{val}"
    
    return f"// {logic_desc}"


def _handle_score_logic(logic_desc: str, qtype_map: Dict[str, str]) -> str:
    """处理打分题逻辑"""
    # B5=7/8/9/10
    m = re.search(r'([A-Z]\d+(?:_\d+)?[a-z]?)[=＝]([\d/]+)', logic_desc)
    if m:
        qid, vals_str = m.group(1), m.group(2)
        vals = [int(v) for v in vals_str.split('/') if v.isdigit()]
        
        if qtype_map.get(qid) == "打分" and vals:
            if min(vals) >= 7 and max(vals) <= 10 and len(vals) >= 3:
                return f"Q.{qid}.score(1) && Q.{qid}.score(1)[0].asInt()>{min(vals)-1}"
            elif max(vals) <= 6 and min(vals) >= 1 and len(vals) >= 4:
                return f"Q.{qid}.score(1) && Q.{qid}.score(1)[0].asInt()<{max(vals)+1}"
    
    # B5=1~6 或 B5=7~10
    m = re.search(r'([A-Z]\d+(?:_\d+)?[a-z]?)[=＝](\d+)~(\d+)', logic_desc)
    if m:
        qid, start, end = m.group(1), int(m.group(2)), int(m.group(3))
        
        if qtype_map.get(qid) == "打分":
            if start >= 7:
                return f"Q.{qid}.score(1) && Q.{qid}.score(1)[0].asInt()>{start-1}"
            elif end <= 6:
                return f"Q.{qid}.score(1) && Q.{qid}.score(1)[0].asInt()<{end+1}"
    
    return None
