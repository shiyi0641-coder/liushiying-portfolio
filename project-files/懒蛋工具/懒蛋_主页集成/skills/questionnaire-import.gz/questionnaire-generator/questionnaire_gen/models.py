"""数据模型定义"""
from dataclasses import dataclass, field
from typing import List, Optional, Tuple


@dataclass
class Option:
    """选项"""
    num: int
    text: str
    is_open: bool = False      # 【开放】
    is_fixed: bool = False     # 【固定】
    is_exclusive: bool = False # 【排他】
    display_code: str = ""
    jump_code: str = ""
    auto_check: str = ""
    group_code: str = ""


@dataclass
class QuestionGroup:
    """题目分组"""
    group_id: str
    name: str
    questions: str
    display_code: str = ""
    group_type: str = ""  # 矩阵行/矩阵列
    dimension_items: List[str] = field(default_factory=list)


@dataclass
class Question:
    """题目"""
    id: str
    title: str
    q_type: str  # 单选/多选/填空/打分/矩单/矩多/矩分/矩空
    options: List[Option] = field(default_factory=list)
    display_code: str = ""
    jump_code: str = ""
    group_code: str = ""
    is_fill_blank: bool = False
    fill_name: str = ""
    matrix_rows: List[str] = field(default_factory=list)
    matrix_cols: List[str] = field(default_factory=list)
    matrix_row_ref: str = ""  # 矩阵行引用（如 "A1" 表示引用A1的选项）
    is_matrix: bool = False
    jump_targets: List[Tuple[str, str]] = field(default_factory=list)
    split_ids: List[str] = field(default_factory=list)
    line_number: int = 0  # 题目在文档中的行号，用于拆分问卷分配
