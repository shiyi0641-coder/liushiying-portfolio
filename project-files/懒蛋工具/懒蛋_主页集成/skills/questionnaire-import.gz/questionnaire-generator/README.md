# QuestionnaireGenerator - 问卷生成器 Skill

自动将在线 docs 问卷文档转换为问卷网导入格式的 Excel 文件。

## 版本说明

### 模块化版本（推荐）
代码按功能拆分为多个模块，更易维护和扩展：

```
questionnaire_gen/
├── __init__.py          # 模块入口
├── models.py            # 数据模型（Question, Option, QuestionGroup）
├── utils.py             # 工具函数（标记解析、题型检测等）
├── logic_converter.py   # 逻辑代码转换
├── markdown_parser.py   # Markdown 解析器
├── group_manager.py     # 分组和拆分问卷管理
├── excel_writer.py      # Excel 生成器
└── main.py              # 主入口
```

**代码统计**:
- 总代码行数: ~933 行（模块化版本）
- 原单个文件: 1553 行
- **减少约 40%**，结构更清晰

### 精简版
`generate_questionnaire_simple.py` (407行) - 核心功能，适合简单需求

## 功能特性

- ✅ Markdown 格式文档解析
- ✅ 自动识别题型（单选/多选/填空/打分/矩阵单选/矩阵多选）
- ✅ 自动转换显示逻辑和跳转逻辑
- ✅ 支持【开放】【固定】【排他】选项标记
- ✅ 支持带下划线的题号格式（A2_1）
- ✅ 自动清理【】标签
- ✅ 支持"同XX"选项引用
- ✅ "结束填答/废卷"自动生成跳转逻辑
- ✅ 支持"--矩阵行--"和"--矩阵列--"标记
- ✅ 拆分问卷自动生成多个文件

## 安装方法

```bash
# 解压到 OpenClaw 的 skills 目录
cd ~/.openclaw/skills
tar -xzf questionnaire-generator.tar.gz

# 安装依赖
pip install pandas openpyxl
```

## 使用方法

### 命令行

```bash
# 使用模块化版本（推荐）
python3 ~/.openclaw/skills/questionnaire-generator/scripts/generate_questionnaire.py \
    "https://docs.corp.kuaishou.com/d/home/xxx" \
    "问卷导入.xlsx"

# 或使用精简版
python3 ~/.openclaw/skills/questionnaire-generator/scripts/generate_questionnaire_simple.py \
    "https://docs.corp.kuaishou.com/d/home/xxx" \
    "问卷导入.xlsx"
```

### 通过 OpenClaw

```
帮我生成问卷网的导入 Excel
文档：https://docs.corp.kuaishou.com/d/home/xxx
```

## 支持的文档格式

```markdown
#### A1. 您平时喜欢看什么题材的网文小说？（可多选）
武侠江湖
仙侠玄幻
其他，请填写【开放，固定】

#### A2_1. 追更情况（单选）【当A2=1时出示】
每天追更
偶尔追更

#### Ba1.【频次】以下任务您都参与过几次？【单选】
--矩阵行--
金币夺宝
金币大挑战
--矩阵列--
仅1次
2-3次

# 拆分-问卷1-通用用户
## Part1. 竞对行为及体验
...
## Part2. 快手激励任务及评价
...
```

## 逻辑代码转换

| 文档描述 | 问卷网代码 |
|----------|-----------|
| 当A1=2时出示 | `Q.A1.select().isin(2)` |
| S2选中1 | `Q.S2.select().include(1)` |
| A2不选1/2 | `Q.A2.select().notin(1,2)` |
| B3=2-6 | `Q.B3.select().isin(2,3,4,5,6)` |
| A1≠11 | `!Q.A1.select().isin(11)` |
| 结束填答/废卷 | `{ next = '2' }` |

## 模块架构

```
┌─────────────────────────────────────┐
│  generate_questionnaire.py (入口)   │
└──────────────┬──────────────────────┘
               │
┌──────────────▼──────────────────────┐
│      questionnaire_gen 包           │
│  ┌──────────────┐ ┌──────────────┐ │
│  │ models.py    │ │ utils.py     │ │
│  │ 数据模型     │ │ 工具函数     │ │
│  └──────────────┘ └──────────────┘ │
│  ┌──────────────┐ ┌──────────────┐ │
│  │ markdown_    │ │ logic_       │ │
│  │ parser.py    │ │ converter.py │ │
│  │ Markdown解析 │ │ 逻辑转换     │ │
│  └──────────────┘ └──────────────┘ │
│  ┌──────────────┐ ┌──────────────┐ │
│  │ group_       │ │ excel_       │ │
│  │ manager.py   │ │ writer.py    │ │
│  │ 分组管理     │ │ Excel生成    │ │
│  └──────────────┘ └──────────────┘ │
│  ┌──────────────┐                  │
│  │ main.py      │                  │
│  │ 主流程整合   │                  │
│  └──────────────┘                  │
└─────────────────────────────────────┘
```

## 扩展开发

如需添加新功能，按模块修改：

- **新题型**: 修改 `utils.py` 中的 `detect_question_type`
- **新逻辑**: 修改 `logic_converter.py` 中的 `convert_logic_to_code`
- **新格式**: 修改 `markdown_parser.py`
- **新输出**: 修改 `excel_writer.py`

## 问题排查

### 无法读取文档
- 检查文档链接是否正确
- 确认文档权限是否公开可读

### 解析题目数量不对
- 检查题号格式（字母+数字，如 A1, B2_1）
- 确保选项在新行

### 逻辑代码未转换
- 检查格式是否为"当X=Y"或"X选中Y"
- 多选题使用 `include`，单选题使用 `isin`
