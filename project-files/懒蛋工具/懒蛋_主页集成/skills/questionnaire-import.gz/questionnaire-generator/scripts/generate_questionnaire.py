#!/usr/bin/env python3
"""
QuestionnaireGenerator - 问卷生成器 (模块化版本)
从在线 docs 问卷生成问卷网导入格式的 Excel 文件
"""

import sys
import os
import subprocess

# 确保可以导入本地模块
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(SCRIPT_DIR))

from questionnaire_gen import parse_doc_content, generate_split_questionnaires, generate_filename_from_content


def call_docs_api(docs_url: str) -> str:
    """调用 docs API 获取文档内容"""
    script_path = os.path.expanduser("~/.openclaw/skills/docs-skills-assistant/scripts/call_skills_api.py")
    result = subprocess.run(
        ["python3", script_path, "summarize", "--url", docs_url],
        capture_output=True, text=True
    )
    if result.returncode != 0:
        raise Exception(f"无法读取文档: {result.stderr}")
    return result.stdout


def main():
    if len(sys.argv) < 2:
        print("用法: python3 generate_questionnaire.py <docs_url> [output.xlsx]")
        sys.exit(1)
    
    docs_url = sys.argv[1]
    output_path = sys.argv[2] if len(sys.argv) >= 3 else "问卷导入.xlsx"
    
    print(f"正在生成问卷...")
    print(f"文档: {docs_url}")
    print("-" * 50)
    
    try:
        print("[1/3] 读取文档...")
        content = call_docs_api(docs_url)
        
        print("[2/3] 解析问卷...")
        questions, groups = parse_doc_content(content)
        print(f"      发现 {len(questions)} 道题目, {len(groups)} 个分组")
        
        # 显示前5道题
        for q in questions[:5]:
            mtag = " [矩阵]" if q.is_matrix else ""
            print(f"      {q.id}: {q.q_type}{mtag} - {q.title[:40]}... ({len(q.options)}个选项)")
        if len(questions) > 5:
            print(f"      ... 还有 {len(questions)-5} 道")
        
        print("[3/3] 生成 Excel...")
        output_files = generate_split_questionnaires(content, output_path)
        
        print("-" * 50)
        print(f"✅ 生成成功! 共 {len(output_files)} 个文件:")
        for f in output_files:
            print(f"   {f}")
        
        # 统计题型
        from collections import Counter
        type_counts = Counter(q.q_type for q in questions)
        print(f"   题型分布: {dict(type_counts)}")
        
    except Exception as e:
        print(f"❌ 错误: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
