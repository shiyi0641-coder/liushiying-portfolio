#!/usr/bin/env python3
"""
QuestionnaireGenerator - 问卷生成器 (精简版)
从在线 docs 问卷生成问卷网导入格式的 Excel 文件

使用方法:
    python3 generate_questionnaire.py <docs_url> [output.xlsx]
"""

import re
import sys
import os
import subprocess
from typing import List, Optional
from dataclasses import dataclass, field


@dataclass
class Question:
    """题目"""
    id: str
    title: str
    q_type: str  # 单选/多选/填空/打分/矩单/矩多
    options: List[dict] = field(default_factory=list)
    display_code: str = ""
    jump_code: str = ""
    matrix_rows: List[str] = field(default_factory=list)
    matrix_cols: List[str] = field(default_factory=list)
    is_matrix: bool = False


def call_docs_api(docs_url: str) -> str:
    """调用 docs API 获取文档内容"""
    script_path = os.path.expanduser("~/.openclaw/skills/docs-skills-assistant/scripts/call_skills_api.py")
    result = subprocess.run(
        ["python3", script_path, "summarize", "--url", docs_url],
        capture_output=True, text=True
    )
    if result.returncode != 0:
        raise Exception(f"无法读取文档: {result.stderr}")
    return result.stdout


def detect_qtype(title: str) -> str:
    """检测题型"""
    t = title.lower()
    if '矩阵单选' in t or '矩单' in t:
        return "矩单"
    if '矩阵多选' in t or '矩多' in t:
        return "矩多"
    if '矩阵打分' in t or '矩分' in t:
        return "矩分"
    if '多选' in t or '可多选' in t:
        return "多选"
    if '打分' in t or '评分' in t:
        return "打分"
    if '填空' in t:
        return "填空"
    return "单选"


def clean_tags(text: str) -> str:
    """清理选项标记【开放，固定，排他】"""
    tags = {'open': False, 'fixed': False, 'exclusive': False}
    for m in re.findall(r'【([^】]+)】', text):
        m_lower = m.lower()
        if '开放' in m_lower:
            tags['open'] = True
        if '固定' in m_lower:
            tags['fixed'] = True
        if '排他' in m_lower or '互斥' in m_lower:
            tags['exclusive'] = True
    text = re.sub(r'【[^】]+】', '', text).strip()
    return text, tags


def build_type_tags(tags: dict) -> str:
    """构建题型标记 [开放][固定][排他]"""
    result = []
    if tags.get('open'):
        result.append("[开放]")
    if tags.get('fixed'):
        result.append("[固定]")
    if tags.get('exclusive'):
        result.append("[排他]")
    return "".join(result)


def convert_logic(desc: str, qtype_map: dict) -> str:
    """转换逻辑说明为问卷网代码"""
    desc = desc.strip()
    
    # 多题号或: S2=1或S3=1
    m = re.search(r'([A-Z]\d+(?:_\d+)?)=(\d+)[或,、]([A-Z]\d+(?:_\d+)?)=(\d+)', desc)
    if m:
        return f"(Q.{m.group(1)}.select().isin({m.group(2)})) || (Q.{m.group(3)}.select().isin({m.group(4)}))"
    
    # 多值或: A1=2或3
    m = re.search(r'([A-Z]\d+(?:_\d+)?)=(\d+)[或,、](\d+)', desc)
    if m:
        return f"Q.{m.group(1)}.select().isin({m.group(2)},{m.group(3)})"
    
    # 范围: B3=2-6
    m = re.search(r'([A-Z]\d+(?:_\d+)?)=(\d+)-(\d+)', desc)
    if m:
        vals = ','.join(str(i) for i in range(int(m.group(2)), int(m.group(3)) + 1))
        return f"Q.{m.group(1)}.select().isin({vals})"
    
    # 多值: B3=1/2/3 或 B3=1,2,3
    m = re.search(r'([A-Z]\d+(?:_\d+)?)=([\d/,]+)', desc)
    if m:
        vals = m.group(2).replace('/', ',')
        return f"Q.{m.group(1)}.select().isin({vals})"
    
    # 不等于: A1≠11 或 A1!=11
    m = re.search(r'([A-Z]\d+(?:_\d+)?)(?:≠|!=|<>)(\d+)', desc)
    if m:
        qid, val = m.group(1), m.group(2)
        if qtype_map.get(qid) == "多选":
            return f"Q.{qid}.select().notinclude({val})"
        return f"Q.{qid}.select().notin({val})"
    
    # 不选: A2不选1/2
    m = re.search(r'([A-Z]\d+(?:_\d+)?)不选([\d/,]+)', desc)
    if m:
        qid, vals = m.group(1), m.group(2).replace('/', ',')
        if qtype_map.get(qid) == "多选":
            return f"Q.{qid}.select().notinclude({vals})"
        return f"Q.{qid}.select().notin({vals})"
    
    # 选中: B1选中8/9/10
    m = re.search(r'([A-Z]\d+(?:_\d+)?)选中?([\d/]+)', desc)
    if m:
        qid, vals = m.group(1), m.group(2).replace('/', ',')
        if qtype_map.get(qid) == "多选":
            return f"Q.{qid}.select().include({vals})"
        return f"Q.{qid}.select().isin({vals})"
    
    # 未选: S2未选2
    m = re.search(r'([A-Z]\d+(?:_\d+)?)未选([\d,]+)', desc)
    if m:
        return f"Q.{m.group(1)}.select().notinclude({m.group(2)})"
    
    # 标准: 当A1=2时出示
    m = re.search(r'当?([A-Z]\d+(?:_\d+)?)=(\d+)', desc)
    if m:
        return f"Q.{m.group(1)}.select().isin({m.group(2)})"
    
    return f"// {desc}"


def parse_markdown(content: str) -> List[Question]:
    """解析 Markdown 格式文档"""
    questions = []
    lines = content.split('\n')
    i = 0
    
    # 预扫描建立题型映射
    qtype_map = {}
    for line in lines:
        m = re.match(r'^[#]*\s*([A-Z]\d+(?:_\d+)?[a-z]?)\.\s*(.+)', line.strip())
        if m:
            qtype_map[m.group(1)] = detect_qtype(m.group(2))
    
    while i < len(lines):
        line = lines[i].strip()
        
        # 匹配题号行
        m = re.match(r'^[#]*\s*([A-Z]\d+(?:_\d+)?[a-z]?)\.\s*(.+)', line)
        if not m and not line.startswith(('- ', '* ', '1.', '2.', '3.', '4.', '5.')):
            m = re.match(r'^([A-Z]\d+(?:_\d+)?[a-z]?)\.\s*(.+)', line)
        
        if not m:
            i += 1
            continue
        
        qid, title = m.group(1), m.group(2)
        qtype = detect_qtype(title)
        
        # 提取逻辑说明
        display_code = ""
        logic_m = re.search(r'[（(]([^）)]+)[）)]', title)
        if logic_m:
            desc = logic_m.group(1)
            if re.match(r'^[A-Z]', desc) or '当' in desc:
                display_code = convert_logic(desc, qtype_map)
                title = re.sub(r'[（(][^）)]+[）)]', '', title)
        
        # 清理标题
        title = re.sub(r'【[^】]+】', '', title).strip()
        title = re.sub(r'[（(]\s*(?:单选|多选|填空|打分)(?:题)?\s*[）)]', '', title)
        
        if not title:
            i += 1
            continue
        
        # 创建题目
        question = Question(
            id=qid, title=title, q_type=qtype,
            options=[], display_code=display_code
        )
        
        # 解析选项
        i += 1
        opt_num = 1
        matrix_rows = []
        matrix_cols = []
        in_matrix_rows = False
        in_matrix_cols = False
        
        while i < len(lines):
            opt_line = lines[i].strip()
            
            # 停止条件
            if not opt_line:
                i += 1
                continue
            if re.match(r'^[#]+\s*[A-Z]\d', opt_line):
                break
            if re.match(r'^[A-Z]\d+(?:_\d+)?[a-z]?\.\s*', opt_line) and not opt_line.startswith(tuple(f'{n}.' for n in range(10))):
                break
            if re.match(r'^#{1,6}\s*[—–\-]', opt_line) or re.match(r'^[—–\-]{2,}', opt_line):
                break
            
            # 检测矩阵标记
            if opt_line in ['--矩阵行--', '——矩阵行——']:
                in_matrix_rows, in_matrix_cols = True, False
                i += 1
                continue
            if opt_line in ['--矩阵列--', '——矩阵列——']:
                in_matrix_rows, in_matrix_cols = False, True
                i += 1
                continue
            
            # 收集矩阵行/列
            if in_matrix_rows and opt_line:
                if re.match(r'^#{1,6}\s+[A-Z]\d', opt_line):
                    break
                row_text, _ = clean_tags(opt_line)
                if row_text:
                    matrix_rows.append(row_text)
                i += 1
                continue
            
            if in_matrix_cols and opt_line:
                if re.match(r'^#{1,6}\s+[A-Z]\d', opt_line):
                    break
                col_text, _ = clean_tags(opt_line)
                if col_text:
                    matrix_cols.append(col_text)
                i += 1
                continue
            
            # 解析普通选项
            opt_text = re.sub(r'^[-*•\d.．]\s*', '', opt_line)
            
            # 检测跳转
            jump_target = None
            jump_match = re.search(r'[\-–—]?(?:跳转|跳)\s*([A-Z]\d+)', opt_text)
            if jump_match:
                jump_target = jump_match.group(1)
                opt_text = re.sub(r'[\-–—]?(?:跳转|跳)\s*[A-Z]\d+', '', opt_text)
            
            # 检测结束关键词
            end_keywords = ['结束填答', '废卷', '结束调研', '被筛选']
            has_end = any(kw in opt_text for kw in end_keywords)
            if has_end:
                jump_target = "END"
                for kw in end_keywords:
                    opt_text = opt_text.replace(kw, '')
            
            # 清理标记
            clean_text, tags = clean_tags(opt_text)
            clean_text = clean_text.strip('，,、 ')
            
            # 过滤特殊选项
            if not clean_text:
                i += 1
                continue
            if re.match(r'^【[^】]+】$', clean_text):  # 【主用平台】
                i += 1
                continue
            if re.match(r'^-[^-]+-$', clean_text):  # -不知道-
                i += 1
                continue
            if clean_text in ['选项', '题号']:
                i += 1
                continue
            
            # 处理"同XX"引用
            ref_match = re.search(r'同\s*([A-Z]\d+)', clean_text)
            if ref_match:
                ref_qid = ref_match.group(1)
                for q in questions:
                    if q.id == ref_qid and q.options:
                        clean_text = "、".join([o['text'] for o in q.options])
                        break
            
            # 添加选项
            option = {
                'num': opt_num,
                'text': clean_text,
                'type_tags': build_type_tags(tags),
                'jump': jump_target
            }
            question.options.append(option)
            
            # 收集跳转逻辑
            if jump_target:
                cond = f"Q.{qid}.select().{'include' if qtype == '多选' else 'isin'}({opt_num})"
                if jump_target == "END":
                    question.jump_code += f"if( {cond} ) {{ next = '2' }} "
                else:
                    question.jump_code += f"if( {cond} ) {{ next = '{jump_target}' }} "
            
            opt_num += 1
            i += 1
        
        # 处理矩阵题
        if matrix_rows or matrix_cols:
            question.is_matrix = True
            question.matrix_rows = matrix_rows
            question.matrix_cols = matrix_cols
            question.q_type = "矩多" if qtype == "多选" else "矩单"
            # 矩阵行作为选项
            for idx, row in enumerate(matrix_rows, 1):
                question.options.append({'num': idx, 'text': row, 'type_tags': '', 'jump': None})
        
        if question.options or qtype == "填空":
            questions.append(question)
        else:
            i += 1
    
    return questions


def generate_excel(questions: List[Question], output_path: str):
    """生成问卷网格式的 Excel"""
    try:
        import pandas as pd
    except ImportError:
        raise Exception("需要安装 pandas: pip install pandas openpyxl")
    
    rows = [['题号/选项号', '题目/选项文字', '题型', '显示代码', '跳转代码', '分组代码', '自动勾选']]
    
    for q in questions:
        # 题目行
        rows.append([q.id, q.title, q.q_type, q.display_code, q.jump_code.strip(), '', ''])
        
        # 选项行
        for opt in q.options:
            rows.append([opt['num'], opt['text'], opt['type_tags'], '', '', '', ''])
        
        rows.append([''] * 7)  # 空行分隔
    
    df = pd.DataFrame(rows)
    df.to_excel(output_path, index=False, header=False)
    return output_path


def main():
    if len(sys.argv) < 2:
        print("用法: python3 generate_questionnaire.py <docs_url> [output.xlsx]")
        sys.exit(1)
    
    docs_url = sys.argv[1]
    output_path = sys.argv[2] if len(sys.argv) >= 3 else "问卷导入.xlsx"
    
    print(f"正在生成问卷...")
    print(f"文档: {docs_url}")
    print("-" * 40)
    
    try:
        print("[1/3] 读取文档...")
        content = call_docs_api(docs_url)
        
        print("[2/3] 解析问卷...")
        questions = parse_markdown(content)
        print(f"      发现 {len(questions)} 道题目")
        
        for q in questions[:5]:
            mtag = " [矩阵]" if q.is_matrix else ""
            print(f"      {q.id}: {q.q_type}{mtag} - {q.title[:30]}... ({len(q.options)}个选项)")
        if len(questions) > 5:
            print(f"      ... 还有 {len(questions)-5} 道")
        
        print("[3/3] 生成 Excel...")
        generate_excel(questions, output_path)
        
        print("-" * 40)
        print(f"✅ 完成: {output_path}")
        print(f"   题目数: {len(questions)}")
        
        # 统计题型
        from collections import Counter
        type_counts = Counter(q.q_type for q in questions)
        print(f"   题型: {dict(type_counts)}")
        
    except Exception as e:
        print(f"❌ 错误: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
